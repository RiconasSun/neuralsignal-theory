import datetime,hashlib,json,subprocess,sys
from pathlib import Path
R=Path(r'C:\Users\85993\Desktop\codebase\neuralsignal institute')
O=Path(__file__).resolve().parent
P='paper13_descriptive_final1/'
E='ops/evidence/2026-10-16/p13-descriptive-final-closeout-1/'
PARENT='2ccf107395f1dee42bc0c27604f639a1ae8432b8'
def git(*a,check=True):return subprocess.run(['git','-C',str(R),*a],capture_output=True,check=check)
def s(*a):return git(*a).stdout.decode('utf8').strip()
def names(*a):return [v.decode('utf8') for v in git(*a).stdout.split(b'\0') if v]
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,x):
 with (O/n).open('x',encoding='utf8') as f:json.dump(x,f,indent=2)
def blobs(ids):
 ids=list(dict.fromkeys(ids));proc=subprocess.run(['git','-C',str(R),'cat-file','--batch'],input=('\n'.join(ids)+'\n').encode(),capture_output=True,check=True)
 out={};pos=0
 for oid in ids:
  stop=proc.stdout.index(b'\n',pos);header=proc.stdout[pos:stop].decode().split();n=int(header[2]);pos=stop+1
  assert header[0]==oid and header[1]=='blob'
  out[oid]=proc.stdout[pos:pos+n];pos+=n+1
 return out
def validate():
 for path in [R/P/'CLOSEOUT_FREEZE.json',R/P/'D_ANALYSIS_FREEZE.json',R/P/'INPUT_FREEZE.json',R/'paper13_ki_execution1/M6_E_IMPLEMENTATION_FREEZE_r2.json',R/'paper13_ki_pl_contract1/FREEZE_r2.json']:
  for n,h in json.loads(path.read_text(encoding='utf8'))['hashes'].items():assert sha((R/n).read_bytes())==h,n
 review=sorted((R/E).glob('FINAL_REVIEW_r*.md'))[-1].read_text(encoding='utf8');assert 'ACCEPTED' in review and 'Open P0: **0**' in review and 'Open P1: **0**' in review
 reproduction=(R/E/'FINAL_SAVED_REPRODUCTION.txt').read_text(encoding='utf8')
 assert 'SAVED_RESULTS_AND_SYNTHETIC_ONLY' in reproduction and 'Ran 96 tests' in reproduction
 result=json.loads((R/P/'results/FINAL_D_RESULTS.json').read_text(encoding='utf8'))
 assert result['FINAL_D_EXECUTION']=='VALIDLY_COMPLETED_ONCE_DESCRIPTIVE' and len(result['mouse_order'])==9
 assert result['null_controls']['conditional_Bstar_status']=='FAILED_UNAVAILABLE'
 assert (R/P/'results/final_D/ONCE_EXECUTION.json').is_file() and not (R/P/'results/FINAL_D_FAILURE.json').exists()
 flags=json.loads((R/E/'DELIVERY_FLAGS.json').read_text(encoding='utf8'))
 assert flags['FINAL_C_PASS'] and flags['FINAL_C_FITS']==198 and flags['FINAL_D_ASSESSMENT_EXECUTED'] and flags['FINAL_MICE_EVALUATED']==9
 assert flags['MANUSCRIPT_COMPLETE'] and flags['CONFIRMATORY_CLAIMS_WITHHELD']
 assert flags['BUG_COUNT']==flags['WARN_COUNT']==0
 assert (R/P/'manuscript/Manuscript.pdf').stat().st_size>10000 and (R/P/'manuscript/Supplement.pdf').stat().st_size>10000
 old=R/'paper13_ki_execution1'
 assert not (old/'results/final_C').exists() and not (old/'results/final_D').exists()
 assert not (old/'FINAL_C_APPROVAL.json').exists() and not (old/'FINAL_D_APPROVAL.json').exists()
 assert json.loads((old/'results/M6_E_CONTROLS_GATE.json').read_text())['M6_E_CONTROLS']=='FAIL'

def stage():
 result=git('fetch','origin','--prune');(O/'fetch_output.txt').write_bytes(result.stdout+result.stderr)
 assert s('branch','--show-current')=='test' and s('rev-parse','HEAD')==PARENT==s('rev-parse','origin/test')
 assert git('show-ref','--verify','--quiet','refs/remotes/origin/main',check=False).returncode!=0
 assert not s('diff','--cached','--name-only')
 validate()
 changed=set(names('diff','--name-only','-z'))|set(names('ls-files','--others','--exclude-standard','-z'))
 assert changed and all(n.startswith(P) or n.startswith(E) or n=='ops/daily-operations.md' for n in changed)
 assert all('/work/' not in n and '/__pycache__/' not in n for n in changed)
 old=git('show',PARENT+':ops/daily-operations.md').stdout
 assert (R/'ops/daily-operations.md').read_bytes().endswith(old)
 manifest=[{'path':n,'bytes':(R/n).stat().st_size,'sha256':sha((R/n).read_bytes())} for n in sorted(changed)]
 pathspec=O/'exact_paths.nul';pathspec.write_bytes(b''.join((':(literal)'+n).encode('utf8')+b'\0' for n in sorted(changed)))
 git('add','--pathspec-from-file='+str(pathspec),'--pathspec-file-nul')
 assert set(names('diff','--cached','--name-only','-z'))==changed
 check=git('-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check',check=False);(O/'staged_diff_check.txt').write_bytes(check.stdout+check.stderr)
 assert check.returncode==0,(check.stdout+check.stderr)[:2000]
 index={}
 for row in git('ls-files','--stage','-z').stdout.split(b'\0'):
  if row:
   meta,n=row.split(b'\t',1);n=n.decode('utf8')
   if n in changed:index[n]=meta.decode().split()[1]
 values=blobs(index.values())
 for item in manifest:
  raw=values[index[item['path']]]
  assert sha(raw)==item['sha256'] and raw==(R/item['path']).read_bytes(),item['path']
  item['index_blob']=index[item['path']]
 save('precommit_manifest.json',manifest)
 save('precommit_gate.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent':PARENT,'origin_test':s('rev-parse','origin/test'),'branch_state':'TEST_ONLY_REMOTE_NO_MAIN','exact_files':len(manifest),'index_bytes_verified':True,'diff_check':True,'full_mission_PASS':False,'task_state':'CLOSURE_IN_PROGRESS','final_C_fits':198,'final_D_evaluated':True,'affected_broad_claims':'INCONCLUSIVE'})
 print(json.dumps({'exact_staged_files':len(manifest),'index_bytes_verified':True,'diff_check':True}))
def commit():
 manifest=json.loads((O/'precommit_manifest.json').read_text());validate()
 assert s('rev-parse','HEAD')==PARENT
 assert set(names('diff','--cached','--name-only','-z'))=={x['path'] for x in manifest}
 for x in manifest:assert sha((R/x['path']).read_bytes())==x['sha256']
 result=git('commit','-m','P13: complete one descriptive final assessment and manuscript with confirmation withheld')
 (O/'commit_output.txt').write_bytes(result.stdout+result.stderr)
 assert s('rev-parse','HEAD^')==PARENT
 save('commit_receipt.json',{'commit':s('rev-parse','HEAD'),'parent':PARENT,'files':len(manifest)})
 print(s('rev-parse','HEAD'))
def push():
 head=s('rev-parse','HEAD');assert head==json.loads((O/'commit_receipt.json').read_text())['commit']
 result=git('-c','http.version=HTTP/1.1','push','origin','test',check=False);(O/'push_output.txt').write_bytes(result.stdout+result.stderr)
 assert result.returncode==0,(result.stdout+result.stderr).decode('utf8',errors='replace')
 save('push_receipt.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':'git -c http.version=HTTP/1.1 push origin test','force':False,'commit':head,'exit_code':result.returncode})
 print(json.dumps({'pushed_origin_test':head}))
def readback():
 manifest=json.loads((O/'precommit_manifest.json').read_text());head=s('rev-parse','HEAD')
 remote=s('ls-remote','--heads','origin','test').split()[0];git('fetch','origin','--prune')
 assert head==remote==s('rev-parse','origin/test') and s('rev-parse','HEAD^')==PARENT
 assert set(names('diff-tree','--no-commit-id','--name-only','-r','-z',head))=={x['path'] for x in manifest}
 tree={}
 for row in git('ls-tree','-r','-z','origin/test').stdout.split(b'\0'):
  if row:
   meta,n=row.split(b'\t',1);tree[n.decode('utf8')]=meta.decode().split()[2]
 values=blobs(tree[x['path']] for x in manifest);records=[]
 for x in manifest:
  raw=values[tree[x['path']]];assert sha(raw)==x['sha256']==sha((R/x['path']).read_bytes()),x['path']
  records.append({'path':x['path'],'remote_blob':tree[x['path']],'sha256':sha(raw)})
 validate();assert not git('status','--porcelain=v1','-z').stdout
 assert git('show-ref','--verify','--quiet','refs/remotes/origin/main',check=False).returncode!=0
 save('remote_readback.json',records)
 flags=json.loads((R/E/'DELIVERY_FLAGS.json').read_text(encoding='utf8'))
 flags['GIT_COMMIT']=head
 flags['REMOTE_VERIFICATION']={'origin_test':remote,'changed_files':len(records),'all_remote_hashes_verified':True,'clean_working_tree':True,'normal_nonforce_push':True}
 save('closure_receipt.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mission':'P13-DESCRIPTIVE-FINAL-CLOSEOUT-1','final_status':'PASS','scope':'Descriptive post-amendment final assessment and paper; affected broad confirmation permanently INCONCLUSIVE','base':PARENT,'commit':head,'origin_test':remote,'changed_files':len(records),'all_remote_hashes_verified':True,'clean_working_tree':True,'normal_nonforce_push':True,'branch_state':'TEST_ONLY_REMOTE_NO_MAIN','baseline_requirement_count':58,'verified_baseline_count':58,'bug_count':0,'warn_count':0,'unresolved_shrink_risk':0,'original_M6':'FAIL_UNAVAILABLE','original_scientific_M6_PASS':False,'all_original_historical_hashes_preserved':True,'final_C_model_fits':198,'final_C_retry':0,'final_D_evaluation_count':1,'final_mice':9,'D_control_mouse_replicates':26973,'conditional_Bstar_new_draws':0,'affected_broad_claims':'INCONCLUSIVE','next_scientific_action_authorized':False,'delivery_flags':flags})
 print(json.dumps({'commit':head,'files':len(records),'remote_hashes_verified':True,'clean':True,'mission_status':'PASS','original_M6':'FAIL_UNAVAILABLE','affected_broad_claims':'INCONCLUSIVE'}))
if __name__=='__main__':{'stage':stage,'commit':commit,'push':push,'readback':readback}[sys.argv[1]]()
