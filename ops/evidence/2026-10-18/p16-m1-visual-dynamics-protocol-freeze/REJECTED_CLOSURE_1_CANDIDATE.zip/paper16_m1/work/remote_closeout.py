from pathlib import Path
import subprocess,json,hashlib,datetime,csv
R=Path.cwd(); P=R/'paper16_m1'; E=R/'ops/evidence/2026-10-18/p16-m1-visual-dynamics-protocol-freeze'
BASE='2adb11a9fcd05cf1ea3cb4e120b5102400d6bb84'
PREFIXES=['paper16_m1/','ops/evidence/2026-10-18/p16-m1-visual-dynamics-protocol-freeze/','ops/evidence/2026-10-18/p16-m1-visual-neurodynamics-protocol-freeze/']
def git(*args, data=None):return subprocess.check_output(['git',*args],cwd=R,input=data)
def permitted(p):return p=='ops/daily-operations.md' or any(p.startswith(x) for x in PREFIXES)
def h(b):return hashlib.sha256(b).hexdigest()
head=git('rev-parse','HEAD').decode().strip(); remote=git('ls-remote','--heads','origin','test','main').decode().splitlines()
assert remote==[head+'\trefs/heads/test'],remote
assert git('rev-parse','origin/test').decode().strip()==head
assert git('status','--porcelain').strip()==b'','Working tree not clean'
assert git('merge-base','--is-ancestor',BASE,head)==b''
paths=git('diff','--name-only','-z',BASE,head).decode().rstrip('\0').split('\0')
assert paths and len(set(paths))==len(paths) and all(permitted(p) for p in paths)
assert git('diff','--name-only','--diff-filter=D',BASE,head)==b''
request=''.join('origin/test:'+p+'\n' for p in paths).encode()
blobs=git('cat-file','--batch',data=request);pos=0; rows=[]
for p in paths:
 end=blobs.index(b'\n',pos);header=blobs[pos:end].decode().split();pos=end+1
 assert len(header)==3 and header[1]=='blob',header
 size=int(header[2]);data=blobs[pos:pos+size];pos+=size
 assert blobs[pos:pos+1]==b'\n';pos+=1
 local=(R/p).read_bytes();assert local==data,p
 oid=hashlib.sha1(b'blob '+str(size).encode()+b'\0'+data).hexdigest();assert oid==header[0]
 rows.append({'path':p,'bytes':size,'git_blob_sha1':oid,'sha256':h(data),'remote_ref':'origin/test','readback_match':True})
assert pos==len(blobs)
manifest=json.loads((P/'M1_FREEZE_MANIFEST.json').read_text(encoding='utf8'))
for x in manifest['files']:assert h((R/x['path']).read_bytes())==x['sha256']
assert (R/'ops/daily-operations.md').read_bytes().endswith(git('show',BASE+':ops/daily-operations.md'))
trace=list(csv.DictReader((E/'REQUIREMENT_TRACE.csv').open(encoding='utf8',newline='')))
assert len(trace)==346 and {x['id'] for x in trace if x['current_status']!='VERIFIED'}=={'REQ-344','REQ-345'}
accept=list(csv.DictReader((E/'ATOMIC_ACCEPTANCE.csv').open(encoding='utf8',newline='')))
assert len(accept)==38 and {x['id'] for x in accept if x['status']!='VERIFIED'}=={'ACC-37'}
receipt={'baseline_verification_overrides':{'REQ-344':'VERIFIED by actual origin/test SHA/allblob readback','REQ-345':'VERIFIED actual commit/clean','ACC-37':'VERIFIED actual Git closure'},'mission':manifest['mission'],'status':'PASS','time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':BASE,'commit':head,'remote_ls_readback':remote,'fetched_origin_test':head,'remote_main':'ABSENT;never invented or created','remote_blob_verification':'Fresh git fetch origin; every changed origin/test blob read through git cat-file --batch and compared byte-for-byte and SHA256/Gitblob against local file','changed_file_count':len(rows),'changed_files':rows,'scientific_manifest_sha256':h((P/'M1_FREEZE_MANIFEST.json').read_bytes()),'scientific_payloads':len(manifest['files']),'baseline_requirement_count':346,'verified_baseline_count':346,'semantic_acceptance_groups':38,'synthetic_tests':51,'bug_count':0,'warn_count':0,'unresolved_shrink_risk':0,'clean_before_receipt':True,'new_neural_arrays':0,'real_model_fits':0,'Final_C_D_executed':False,'STOP_after_M1':True}
output=P/'work/closure_receipt.json';assert not output.exists();output.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
assert git('status','--porcelain').strip()==b''
receipt['clean_after_receipt']=True;output.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in receipt.items() if k!='changed_files'}))
