# P16 VISp prospective protocol

Mission: P16-M1-VISUAL-NEURODYNAMICS-PROTOCOL-FREEZE.
BASE: 2adb11a9fcd05cf1ea3cb4e120b5102400d6bb84.
Scientific status: **M1_FROZEN_PENDING_NATIVE_STIMULUS_QC**. Prompt 3 ready: **FALSE**.

Working title: Predictive Contributions of Local Spike History in Mouse Primary Visual Cortex.
Does strictly past local VISp history improve future count prediction beyond a strong visual, session, rate and measured-running baseline? Primary B4−B1; secondary B4−B3 (own history conditional on population) and B4−B2 (population conditional on own). This is observational prediction, not connectivity, physical states, stimulus-independent mechanism, cognitive primitives, consciousness or BCI performance.

The machine-readable protocol.json, NUMERICAL_POLICY.json and controls.json are normative alongside these equations and analysis rules. The freeze manifest binds all files and original M0 source identities. No P15 constants or code are silently inherited.

Exactly one primary family: source nominal black/white flashes. Score 20-ms count bins in [100,220) ms after native onset, six bins/presentation, following 100 ms strictly within-flash history. Eight fixed A/C-qualified units on the original selected VISp probe. B1 has a saturated nominal condition × score-time-bin response plus twelve source-specific nuisances. History models are convex nested GLMs. D/C/S real comparisons are excluded prospectively; short exposure, unknown physiological attrition and five BO development candidates do not support an additional latent-state study. Their synthetic identities are mathematical examples only. No temporal-state or discrete-superiority claim is registered.

All 55 original metadata candidates remain: Development 28 (5 BO,23 FC), reserved Final 27 BO. Source-family presence 55/55; full native flash parameters verified in only the two original Development pilots. These are not 55 physiological admissions. Future stages separately journal source compatibility, timing/support, A physiology, C physiology and actual D coverage. No replacement or reroll. All historically exposed animals remain Development.

This entire track is prospective descriptive/exploratory. No P16 predictive effect or animal variance has been measured. Hypothetical planning cannot justify confirmation. Even a positive future test cannot produce VALIDATED. Development is exploratory; Final is independent-animal BO transport within a single Allen source, not an IID protocol split or independent-laboratory replication.

Future progression requires native stimulus/behavior/source gates, synthetic production-worker certification, A admission, fixed B selection, one E descriptive batch, development freeze, separate C authorization and C-only isolation, complete C state seal, independent pre-D review and separate owner authorization for exactly one D batch including all controls. This M1 authorizes none of that neural execution.

Stop on mandatory source, physiological coverage, numerical or implementation failure. No failed fit retry or post-result repair, new hypothesis, cohort change, threshold relaxation or model rescue. Final 6–11 is a registered descriptive fallback retaining the original 12-mouse main-coverage FAIL; below six STOP before D. The fallback never bypasses numerical/source/approval gates.

Read STIMULUS_CONTRACT, SOURCE_OBSERVATION_QC, FEATURE_AND_MODEL_EQUATIONS, STATISTICAL_ANALYSIS_PLAN, FALSIFICATION_AND_SENSITIVITY_PLAN and EVALUATION_BOUNDARY for the exact operative definitions. M1 completion certifies a reviewed specification, not neural validation or a completed paper. All M0 and P1–P15 evidence and roadmap tracks remain immutable.
