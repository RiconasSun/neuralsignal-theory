# Prospective A1–A10 claim audit

This is a protocol attachment, not a manuscript or scientific-result claim.

|ID|Claim boundary and evidence|Unexecuted requirement|
|---|---|---|
|A1|Exact owner request/BASE,distinct VISp track; prior transcriptomic/closed-loop tracks preserved|No theory/primitive proof|
|A2|Source/license/source modules,55 original metadata candidates,FROZEN_COHORT|Full native source/physiology admissions|
|A3|One nominal-flash late-window estimand,20ms/strict past/actual denominator|No full-evoked-response or physical-display identity|
|A4|A/B/E,C/D original chronological cuts/no reroll|Future C isolation and separate D authority|
|A5|B0–B4 equations,exact nesting/scalers/counts; D/C/S withheld|Production implementation independently certified later|
|A6|Frozen gradients/PG/optimizer/budgets; synthetic oracles|No real fit numerical PASS|
|A7|Equal-mouse Holm3,CI/sign assumptions/hypothetical planning|No empirical effect,power or confirmation|
|A8|12 sensitivity/four bounded operators,assumption limits|No executed real null or robustness PASS|
|A9|BO/FC transport,source/QC/anatomy/behavior limitations|No mechanism,independent lab,all arousal or BCI claim|
|A10|Hash manifest,saved-only PS,independent review,origin/test archive|M1 specification completion≠biological validation|

Negative,mixed,inconclusive and unavailable outcomes are mandatory future reporting. Every P1–P15 and M0 failure remains immutable; no heldout reuse or retrospective PASS. M1_FROZEN_PENDING_NATIVE_STIMULUS_QC and Prompt3 false explicitly prevent claiming immediate neural execution readiness.
