# Fixed protocol transport boundary

Development: 5 BO and 23 FC; Final: 27 BO. FROZEN_COHORT.csv preserves exact original mouse/session/probe/sex/genotype and original role. No cross-probe, session or mouse pooling. This is protocol-distribution shift, not an IID split. Protocols were not randomized and cannot identify a causal protocol effect.

Future minimum A admissions: 14 total including ≥3 BO and ≥10 FC. B chooses one ridge using mean B1 logscore: equal mouse within BO and FC, then .5 BO + .5 FC. No score-driven reweighting. E reports BO-only and FC-only gains, CIs, exposures, unit/rate/QC, sex/genotype and source/batch composition separately, plus equal-mouse pooled descriptions. Final remains BO only. No inference that all 55 or all source animals qualify.

Final main requires ≥12 independently admitted mice; 6–11 preserves a failed main coverage gate and descriptive-only one-shot fallback, subject to independent pre-D approval; <6 stops before D. This is a precision/coverage planning floor, not proof of power. No animal substitutions. Protocol, acquisition-date/batch, genotype and sex concentration are reported; no independent-laboratory replication is claimed. Unidentified batch dependence limits sign-flip/bootstrap interpretation rather than being treated as extra independent samples.
