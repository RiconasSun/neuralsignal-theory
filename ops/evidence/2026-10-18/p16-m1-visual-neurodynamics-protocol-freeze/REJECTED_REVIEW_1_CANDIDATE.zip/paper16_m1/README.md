# Paper 16 M1 handoff

Scientific status: M1_FROZEN_PENDING_NATIVE_STIMULUS_QC. Prompt3_ready=false. Complete reviewed prospective specification; no new neural data, real fits, or Final C/D.

Read M1_SCIENTIFIC_PROTOCOL.md; protocol.json/NUMERICAL_POLICY.json/controls.json contain exact machine-readable settings. FROZEN_COHORT.csv preserves55 original candidates/28Dev27Final. Full native stimulus tables are verified for only two Development pilots. Review and evidence: ../ops/evidence/2026-10-18/p16-m1-visual-neurodynamics-protocol-freeze/.

Saved-only reproduction from repository root in Windows PowerShell:

```powershell
& .\paper16_m1eproduce.ps1
```

Requires Python3.11.15,NumPy2.4.6,SciPy1.16.3. The included local ignored work/runtime is one installed environment; for another host create an environment with those pinned versions and pass -Python <full-python.exe>. The reproduction is offline, reads saved metadata/protocols only, performs small synthetic mathematical checks, and never invokes stimulus_metadata.py or opens NWB. No real training or evaluation is authorized. All commands fail on hash mismatch. Source metadata acquisition failures/test corrections remain preserved in evidence.

No paper PDF is due in M1. STOP after the verified protocol archive, no automatic Prompt3.
