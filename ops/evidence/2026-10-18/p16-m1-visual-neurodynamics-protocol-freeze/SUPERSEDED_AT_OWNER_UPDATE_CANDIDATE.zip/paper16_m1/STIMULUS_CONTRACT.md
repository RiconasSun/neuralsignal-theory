# Source-defined nominal flash contract

Primary source remains Allen Visual Coding Neuropixels curated NWB 2.2.2, under the applicable noncommercial Allen research terms established in M0. AllenSDK 2.16.2 source definitions are inspected at commit a9b5c685396126d9748f1ccecf7c00f440569f69; the SDK package was not executed. M0 actually used PyNWB 3.1.3. M1 reads only an explicit stimulus-metadata allowlist with h5py from the two existing Development containers; no neural dataset was loaded. Exact module text, request receipts, license and native metadata NPZ are archived under metadata/.

Official definition: https://raw.githubusercontent.com/AllenInstitute/AllenSDK/a9b5c685396126d9748f1ccecf7c00f440569f69/allensdk/brain_observatory/ecephys/stimulus_analysis/flashes.py . Source nominal color −1/+1 denotes black/white, default duration .25 s. Color −1 is a nominal category, not absence of observation. No assertion of identical monitor radiometry, actual luminance, gamma or physical display across rigs is supported. No outcome-driven color remapping.

Both original pilots have 150 presentations, 75/category. BO durations [.250186980674016,.250216980674168] s, blank gaps [1.751403019325835,1.751533019325962] s; onset spacing is approximately 2.0016 s, not a two-second blank gap. Exact FC ranges and all native timestamps/IDs are in FLASH_NATIVE_829720705.json/npz. Common parameters: contrast .8, opacity 1, size [300,300] degrees, phase [0,0], spatial frequency [0,0], mask None. Source nominal equivalence is defensible; physical equivalence is not established.

Future source gate, before neural admission: 120–180 original presentations, only ±1 colors, these exact source parameter values, finite strictly increasing starts, stop>start, durations [.23,.28] s, gaps [1.5,2.0] s, full block span ≤400 s. Original IDs, order, repeats and native binary64 times preserved. Source-invalid periods are subtracted per probe/global scope, never converted to zero counts. Unexpected metadata/clock/parameter values fail compatibility without a replacement stimulus.

Chronological cuts use the entire original native table before exclusion: A first floor(.6N), B next through floor(.8N), E remaining; C first floor(.6N), D remaining. Never reshuffle for balance. Per-color valid presentation minima A30/B8/E8/C30/D15. BO pilot has A45/45,B15/15,E15/15; FC A42/48,B14/16,E19/11. Counterfactual C/D metadata cuts on these Development pilots are design checks only, not Final access. No per-mouse Final full table is verified here. Family-name metadata presence is 55/55; full native table coverage 2/55.

Score [100,220) ms is within all registered valid flashes. Onset is available only strictly before a score-bin start; no actual future offset is a feature. Scheduled color/onset may be used after observation. The primary analysis excludes early onset response and pre-onset activity: it cannot describe the full evoked response or sub-20-ms ordering.

Alternative gratings were examined using existing M0 evidence: orientations 0/45/90/135°, 2 Hz, .04 cycles/degree, contrast .8 are partial support. Phase-at-onset remains unresolved. No phase correction is invented and gratings are not registered as a fallback. No third-family rescue.

## Prospective revision 2: complete presentations and rate domains

A main valid presentation requires every selected unit to support the entire original onset through anchored edge11=onset+.22s, all six scored bins and100ms withinflash history, with no known-invalid overlap. Otherwise exclude entire presentation for all main models. Count only these complete presentations for each role/color floor; each color/time PSTH cell must independently meet that same role/color minimum.

For unit u,use only complete main A (Development) or C (Final) registered scored rows k5..10: R_u=sum(y_u)/sum(actual full-bin exposure .02s). Never QC early0..100ms counts. B0 eta=clip(log R_u,-6,6), R=0 -> -6. Every B1/B2/B3/B4 PSTH initializes to that same unit value; other coefficients0. Sensitivity initializers use that panel A/C scored rows/exposures, never a QC window.

Physiological QC alone uses the separate[0,220) window. No earlier warmup spike can change fitted B0 or coefficient initialization. Source anatomical candidates are exactly the original M0 role qualified_unit_ids, rechecked against VISp,VISp1,VISp2/3,VISp4,VISp5,VISp6a,VISp6b on the frozen probe; S11 inherits this same list. A selected VISp probe does not imply all its units are VISp.
